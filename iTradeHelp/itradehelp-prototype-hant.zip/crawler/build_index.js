console.log('Index builder stub – run after crawl to generate web/public/index.json');
