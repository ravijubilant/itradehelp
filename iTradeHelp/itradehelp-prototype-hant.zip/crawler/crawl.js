console.log('Crawler stub – run in your environment to fetch live pages.');
